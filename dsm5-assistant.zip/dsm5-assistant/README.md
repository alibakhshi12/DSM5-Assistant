# DSM-5-inspired symptom-pattern assistant

Research prototype: a 5-member MLP ensemble (pure NumPy) estimates how closely reported symptoms resemble 12 conditions; an LLM turns free text into structured symptoms and explains the result. **Not a diagnostic tool.** Trained on synthetic data generated from *paraphrased* criteria (DSM-5 text is copyrighted and not included).

## Run
```bash
pip install numpy scipy scikit-learn matplotlib flask
python data/generate.py        # synthetic data
python model/train.py          # train, calibrate, evaluate -> artifacts/
python tests/test_pipeline.py  # sanity tests
export ANTHROPIC_API_KEY=...   # optional: enables LLM extraction/explanation
python backend/app.py          # open http://127.0.0.1:8000
python ui/build_standalone.py  # offline one-file UI: dist/dsm5-assistant-standalone.html
```
Without an API key the app falls back to a keyword extractor and a template explanation.

## Layout
- `data/knowledge.py` symptom/condition knowledge base · `data/generate.py` case generator
- `model/mlp.py` NumPy MLP + Adam · `model/train.py` training/eval · `model/infer.py` inference + occlusion explanations
- `backend/llm.py` LLM layer · `backend/app.py` Flask API · `ui/index.html` Persian RTL UI
- `artifacts/` weights, metrics, figures · `tests/` Python tests and JS/Python parity check (`node tests/js_parity.js <ids> <duration> <0|1>`)

## Key results (synthetic test set)
Macro AUROC 0.979 (95% CI 0.977–0.980) vs 0.974 for logistic regression; ECE 0.003. These measure consistency with the generator, not clinical validity.
