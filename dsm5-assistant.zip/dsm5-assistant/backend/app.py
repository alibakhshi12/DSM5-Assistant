"""Flask server: serves the UI and exposes /api/meta, /api/extract, /api/predict."""
import os
import sys

from flask import Flask, jsonify, request, send_from_directory

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for sub in ("data", "model", "backend"):
    sys.path.insert(0, os.path.join(ROOT, sub))

import llm  # noqa: E402
from infer import Predictor  # noqa: E402
from knowledge import SYMPTOMS  # noqa: E402

app = Flask(__name__, static_folder=None)
predictor = Predictor()
KEYWORDS = {s[0]: s[4] for s in SYMPTOMS}
UI_DIR = os.path.join(ROOT, "ui")
ART_DIR = os.path.join(ROOT, "artifacts")


@app.get("/")
def index():
    return send_from_directory(UI_DIR, "index.html")


@app.get("/model.json")
def model_json():
    return send_from_directory(ART_DIR, "model.json")


@app.get("/api/meta")
def meta():
    return jsonify({"symptoms": predictor.symptoms, "disorders": predictor.disorders,
                    "durations": predictor.durations, "llm_enabled": bool(os.environ.get("ANTHROPIC_API_KEY"))})


@app.post("/api/extract")
def extract():
    text = (request.get_json(silent=True) or {}).get("text", "").strip()[:4000]
    if not text:
        return jsonify({"error": "empty text"}), 400
    return jsonify(llm.extract(text, predictor.symptoms, predictor.durations, KEYWORDS))


@app.post("/api/predict")
def predict():
    body = request.get_json(silent=True) or {}
    symptoms = [s for s in body.get("symptoms", []) if s in predictor.s_idx]
    pred = predictor.predict(symptoms, body.get("duration", "2w_6m"), bool(body.get("impairment", True)))
    selected_fa = [predictor.symptoms[predictor.s_idx[s]]["fa"] for s in symptoms]
    text, engine = llm.explain(pred, selected_fa) if body.get("explain", True) and symptoms else ("", "none")
    pred.update({"explanation": text, "explanation_engine": engine, "disclaimer": llm.DISCLAIMER_FA})
    return jsonify(pred)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 8000)), debug=False)
