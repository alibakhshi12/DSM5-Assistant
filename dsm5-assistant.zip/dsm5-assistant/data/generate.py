"""Synthetic case generator driven by the paraphrased knowledge base (see knowledge.py)."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from knowledge import (BASE_RATE, BASE_RATE_DEFAULT, D_INDEX, DISORDER_IDS, DISORDERS, S_INDEX,  # noqa: E402
                       SYMPTOM_IDS, affinity)

S, D = len(SYMPTOM_IDS), len(DISORDER_IDS)
N_CTX = 4  # 3 duration one-hots + impairment flag
BASE = np.array([BASE_RATE.get(s, BASE_RATE_DEFAULT) for s in SYMPTOM_IDS])
PROTO = np.zeros((D, S))
for d, meta in DISORDERS.items():
    for s, p in meta["probs"].items():
        PROTO[D_INDEX[d], S_INDEX[s]] = p
DUR = np.array([DISORDERS[d]["duration"] for d in DISORDER_IDS])


def _pick_disorders(rng, k):
    chosen = [int(rng.integers(D))]
    while len(chosen) < k:
        w = np.ones(D)
        for j in range(D):
            if j in chosen:
                w[j] = 0
            else:
                w[j] = np.mean([affinity(DISORDER_IDS[c], DISORDER_IDS[j]) for c in chosen])
        chosen.append(int(rng.choice(D, p=w / w.sum())))
    return chosen


def sample(n, seed, miss_rate=0.05, false_rate=0.01):
    """Return X (n, S+4) float32 and Y (n, D) float32."""
    rng = np.random.default_rng(seed)
    X = np.zeros((n, S + N_CTX), dtype=np.float32)
    Y = np.zeros((n, D), dtype=np.float32)
    for i in range(n):
        u = rng.random()
        k = 0 if u < 0.10 else 1 if u < 0.62 else 2 if u < 0.90 else 3
        sev = 0.55 + 0.9 * rng.beta(2.5, 2.5)
        if k == 0:
            # healthy, or sub-threshold presentation of one disorder (hard negative)
            chosen = _pick_disorders(rng, 1) if rng.random() < 0.6 else []
            scale, labelled = 0.3, []
        else:
            chosen = _pick_disorders(rng, k)
            scale, labelled = sev, chosen
        p_absent = 1 - BASE
        for c in chosen:
            p_absent = p_absent * (1 - np.clip(PROTO[c] * scale, 0, 0.98))
        present = rng.random(S) < (1 - p_absent)
        # reporting noise
        flip_off = present & (rng.random(S) < miss_rate)
        flip_on = (~present) & (rng.random(S) < false_rate)
        present = (present & ~flip_off) | flip_on
        X[i, :S] = present
        # context: duration bucket + impairment
        if chosen:
            dur_p = DUR[chosen[int(rng.integers(len(chosen)))]]
        else:
            dur_p = np.array([0.6, 0.3, 0.1])
        X[i, S + rng.choice(3, p=dur_p)] = 1
        impaired = rng.random() < (0.95 if labelled else (0.3 if chosen else 0.1))
        X[i, S + 3] = impaired
        for c in labelled:
            Y[i, c] = 1
    return X, Y


def build(out_dir, n_train=20000, n_val=4000, n_test=6000):
    os.makedirs(out_dir, exist_ok=True)
    sets = {"train": (n_train, 1), "val": (n_val, 2), "test": (n_test, 3)}
    for name, (n, seed) in sets.items():
        X, Y = sample(n, seed)
        np.savez_compressed(os.path.join(out_dir, f"{name}.npz"), X=X, Y=Y)
    return sets


if __name__ == "__main__":
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "synthetic")
    build(out)
    X, Y = np.load(os.path.join(out, "train.npz"))["X"], np.load(os.path.join(out, "train.npz"))["Y"]
    print("train", X.shape, Y.shape)
    print("prevalence:", {d: round(float(Y[:, j].mean()), 3) for d, j in D_INDEX.items()})
    print("mean #labels:", round(float(Y.sum(1).mean()), 2), "| no-label share:", round(float((Y.sum(1) == 0).mean()), 3))
