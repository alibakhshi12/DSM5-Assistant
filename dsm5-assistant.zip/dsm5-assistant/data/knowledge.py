"""
Structured, *paraphrased* symptom knowledge base inspired by DSM-5 diagnostic criteria.

IMPORTANT
---------
* The DSM-5 / DSM-5-TR text is copyrighted by the American Psychiatric Association.
  Nothing here is copied from it: symptom labels are short, original paraphrases and
  the per-disorder probabilities are *modelling assumptions* (core / common / occasional),
  not official statistics.
* This knowledge base drives a synthetic data generator. It is NOT clinical ground truth.
"""

# (id, group_fa, label_fa, label_en, keywords for the offline fallback extractor)
SYMPTOMS = [
    # --- mood ---------------------------------------------------------------
    ("depressed_mood", "خلق", "خلق افسرده در بیشتر ساعات روز", "Depressed mood most of the day",
     ["غمگین", "افسرده", "دپرس", "depressed", "feel sad", "sad mood"]),
    ("anhedonia", "خلق", "از دست دادن علاقه یا لذت", "Loss of interest or pleasure",
     ["علاقه", "لذت", "انگیزه ندارم", "anhedonia", "no interest", "enjoy"]),
    ("hopelessness", "خلق", "احساس ناامیدی", "Feelings of hopelessness",
     ["ناامیدی", "ناامید", "hopeless"]),
    ("worthlessness_guilt", "خلق", "احساس بی‌ارزشی یا گناه", "Worthlessness or excessive guilt",
     ["بی‌ارزش", "بی ارزش", "احساس گناه", "worthless", "guilt"]),
    ("suicidal_thoughts", "خلق", "افکار مرگ یا آسیب به خود", "Thoughts of death or self-harm",
     ["خودکشی", "بمیرم", "مردن", "آسیب به خود", "suicid", "want to die", "self-harm", "kill myself"]),
    ("elevated_mood", "خلق", "سرخوشی یا خلق بالای غیرعادی", "Abnormally elevated mood",
     ["سرخوش", "خلق بالا", "euphori", "elevated mood", "high mood"]),
    ("irritability", "خلق", "تحریک‌پذیری و زودرنجی", "Irritability",
     ["تحریک‌پذیر", "تحریک پذیر", "زودرنج", "عصبانی", "irritab", "angry"]),
    ("grandiosity", "خلق", "اعتمادبه‌نفس یا احساس بزرگی غیرعادی", "Inflated self-esteem / grandiosity",
     ["بزرگ‌بینی", "بزرگ بینی", "احساس قدرت", "grandio"]),
    ("increased_goal_activity", "خلق", "پرانرژی بودن و فعالیت هدف‌مند بیش از حد", "Increased energy / goal-directed activity",
     ["پرانرژی", "فعالیت زیاد", "increased energy", "more active"]),
    ("talkativeness", "خلق", "پرحرفی و فشار برای حرف زدن", "Pressured or excessive talking",
     ["پرحرف", "پر حرف", "pressured speech", "talkative"]),
    ("racing_thoughts", "خلق", "افکار پرشتاب", "Racing thoughts",
     ["افکار پرشتاب", "افکارم می‌دوند", "racing thoughts"]),
    ("risky_behavior", "خلق", "رفتار پرخطر (مثلاً ولخرجی)", "Risky behaviour (e.g. spending sprees)",
     ["پرخطر", "ولخرجی", "risky", "spending spree"]),
    # --- sleep / energy / appetite --------------------------------------------
    ("insomnia", "خواب و انرژی", "بی‌خوابی (شروع یا تداوم خواب)", "Insomnia (onset or maintenance)",
     ["بی‌خواب", "بی خواب", "خوابم نمی", "insomnia", "can't sleep", "cannot sleep", "trouble sleeping"]),
    ("hypersomnia", "خواب و انرژی", "پرخوابی", "Hypersomnia",
     ["پرخواب", "زیاد می‌خوابم", "زیاد میخوابم", "oversleep", "hypersomnia"]),
    ("reduced_sleep_need", "خواب و انرژی", "نیاز کم به خواب بدون احساس خستگی", "Decreased need for sleep",
     ["نیاز به خواب کم", "بدون خواب", "need less sleep", "little sleep"]),
    ("fatigue", "خواب و انرژی", "خستگی یا بی‌انرژی بودن", "Fatigue or low energy",
     ["خستگی", "خسته", "بی‌انرژی", "بی انرژی", "fatigue", "tired", "exhausted"]),
    ("appetite_decrease", "خواب و انرژی", "کاهش اشتها", "Decreased appetite",
     ["کم‌اشتها", "اشتها ندارم", "کاهش اشتها", "loss of appetite", "decreased appetite"]),
    ("appetite_increase", "خواب و انرژی", "افزایش اشتها", "Increased appetite",
     ["افزایش اشتها", "اشتهای زیاد", "increased appetite"]),
    # --- cognition ---------------------------------------------------------------
    ("poor_concentration", "شناخت و تمرکز", "ضعف تمرکز", "Poor concentration",
     ["تمرکز", "concentrat", "focus"]),
    ("indecisiveness", "شناخت و تمرکز", "دشواری تصمیم‌گیری", "Indecisiveness",
     ["تصمیم", "indecis", "decisions"]),
    ("distractibility", "شناخت و تمرکز", "حواس‌پرتی آسان", "Easily distracted",
     ["حواس‌پرت", "حواسم پرت", "حواس پرت", "distractib", "easily distracted"]),
    ("psychomotor_agitation", "شناخت و تمرکز", "بی‌قراری حرکتی قابل مشاهده", "Observable psychomotor agitation",
     ["بی‌قراری حرکتی", "agitation"]),
    ("psychomotor_slowing", "شناخت و تمرکز", "کندی حرکت و تفکر", "Psychomotor slowing",
     ["کندی", "slowed down", "slowed"]),
    # --- anxiety -----------------------------------------------------------------
    ("excessive_worry", "اضطراب", "نگرانی بیش از حد درباره چند موضوع", "Excessive worry about several areas",
     ["نگران", "worry", "worried"]),
    ("worry_hard_to_control", "اضطراب", "ناتوانی در کنترل نگرانی", "Difficulty controlling worry",
     ["کنترل نگرانی", "can't stop worrying", "cannot control worry", "can't control my worry"]),
    ("restlessness", "اضطراب", "کلافگی یا احساس «لبه‌ی پرتگاه»", "Restlessness / feeling on edge",
     ["کلافه", "بی‌قرار", "on edge", "keyed up", "restless"]),
    ("muscle_tension", "اضطراب", "تنش عضلانی", "Muscle tension",
     ["تنش عضلانی", "گرفتگی عضله", "muscle tension"]),
    ("panic_attacks", "اضطراب", "حملات ناگهانی وحشت", "Sudden panic attacks",
     ["حمله پنیک", "حمله وحشت", "پنیک", "panic attack"]),
    ("fear_of_attacks", "اضطراب", "ترس از تکرار حمله یا تغییر رفتار به‌خاطر آن", "Fear of further attacks / behaviour change",
     ["ترس از تکرار", "another attack", "fear of attacks"]),
    ("palpitations", "اضطراب", "تپش قلب", "Palpitations",
     ["تپش قلب", "palpitation", "racing heart", "heart pounding"]),
    ("shortness_breath", "اضطراب", "تنگی نفس یا احساس خفگی", "Shortness of breath / choking feeling",
     ["تنگی نفس", "خفگی", "shortness of breath"]),
    ("dizziness", "اضطراب", "سرگیجه یا سبکی سر", "Dizziness / lightheadedness",
     ["سرگیجه", "dizz", "lightheaded"]),
    ("fear_of_scrutiny", "اضطراب", "ترس از قضاوت یا ارزیابی دیگران", "Fear of judgment by others",
     ["قضاوت", "judged", "scrutiny", "embarrass"]),
    ("avoidance_social", "اضطراب", "اجتناب از موقعیت‌های اجتماعی", "Avoiding social situations",
     ["اجتناب از جمع", "دوری از جمع", "avoid social", "avoid parties"]),
    ("social_physical", "اضطراب", "سرخ شدن یا لرزش در جمع", "Blushing / trembling around others",
     ["سرخ می‌شوم", "سرخ میشوم", "لرزش", "blush", "tremble"]),
    # --- trauma ------------------------------------------------------------------
    ("traumatic_event", "تروما", "مواجهه با رویداد تروماتیک", "Exposure to a traumatic event",
     ["تصادف", "تجاوز", "جنگ", "تروما", "trauma", "assault", "accident"]),
    ("intrusive_memories", "تروما", "خاطرات مزاحم و ناخواسته", "Intrusive memories",
     ["خاطرات مزاحم", "intrusive memor"]),
    ("nightmares", "تروما", "کابوس", "Nightmares",
     ["کابوس", "nightmare"]),
    ("flashbacks", "تروما", "فلش‌بک (زنده شدن صحنه)", "Flashbacks",
     ["فلش‌بک", "فلش بک", "فلاش‌بک", "flashback"]),
    ("avoidance_trauma", "تروما", "اجتناب از یادآورهای رویداد", "Avoiding reminders of the event",
     ["اجتناب از یادآور", "avoid reminders"]),
    ("hypervigilance", "تروما", "گوش‌به‌زنگی مفرط", "Hypervigilance",
     ["گوش به زنگ", "گوش‌به‌زنگ", "hypervigil", "on guard"]),
    ("startle", "تروما", "جا خوردن شدید", "Exaggerated startle response",
     ["جا می‌خورم", "جا میخورم", "جا خوردن", "startle"]),
    ("emotional_numbness", "تروما", "بی‌حسی عاطفی و فاصله از دیگران", "Emotional numbness / detachment",
     ["بی‌حس", "بی حس", "numb"]),
    ("negative_beliefs", "تروما", "باورهای منفی شدید درباره خود یا دنیا", "Persistent negative beliefs about self/world",
     ["دنیا جای خطرناک", "negative beliefs", "world is dangerous"]),
    # --- OCD ---------------------------------------------------------------------
    ("obsessions", "وسواس", "افکار وسواسی مزاحم", "Intrusive obsessive thoughts",
     ["وسواس", "افکار مزاحم تکراری", "obsession", "intrusive thoughts"]),
    ("compulsion_cleaning", "وسواس", "شست‌وشو یا پاکسازی اجباری", "Compulsive washing / cleaning",
     ["شست‌وشو", "شستشو", "دست می‌شورم", "دست میشورم", "washing", "cleaning ritual"]),
    ("compulsion_checking", "وسواس", "وارسی مکرر", "Repeated checking",
     ["چک کردن مکرر", "وارسی", "checking", "check repeatedly"]),
    ("ritual_time", "وسواس", "آیین‌های زمان‌بر (حدود بیش از ۱ ساعت در روز)", "Time-consuming rituals (>~1 h/day)",
     ["بیش از یک ساعت", "hour a day", "time-consuming"]),
    # --- ADHD --------------------------------------------------------------------
    ("inattention_details", "توجه و تکانشگری", "بی‌دقتی و اشتباهات سهوی", "Careless mistakes",
     ["بی‌دقت", "بی دقت", "careless", "silly mistakes"]),
    ("sustained_attention", "توجه و تکانشگری", "دشواری حفظ توجه در کارها", "Difficulty sustaining attention",
     ["حفظ توجه", "sustain attention", "lose focus"]),
    ("losing_things", "توجه و تکانشگری", "گم کردن مکرر وسایل", "Frequently losing things",
     ["گم می‌کنم", "گم میکنم", "losing things", "misplace"]),
    ("disorganization", "توجه و تکانشگری", "بی‌نظمی و ضعف سازمان‌دهی", "Disorganisation",
     ["بی‌نظم", "بی نظم", "disorganiz", "disorganis"]),
    ("fidgeting", "توجه و تکانشگری", "ناتوانی در آرام نشستن", "Fidgeting / unable to sit still",
     ["آرام بنشینم", "fidget", "can't sit still"]),
    ("impulsivity", "توجه و تکانشگری", "تکانشگری", "Impulsivity",
     ["تکانشگر", "impulsiv"]),
    ("interrupting", "توجه و تکانشگری", "قطع کردن صحبت دیگران", "Interrupting others",
     ["وسط حرف", "interrupt"]),
    ("childhood_onset", "توجه و تکانشگری", "شروع علائم از کودکی", "Symptoms since childhood",
     ["از بچگی", "از کودکی", "since childhood", "childhood onset"]),
    # --- eating ------------------------------------------------------------------
    ("binge_episodes", "خوردن", "دوره‌های پرخوری", "Binge-eating episodes",
     ["پرخوری", "binge"]),
    ("loss_of_control_eating", "خوردن", "از دست دادن کنترل هنگام خوردن", "Loss of control while eating",
     ["کنترل هنگام خوردن", "loss of control eating", "can't stop eating"]),
    ("eating_rapidly", "خوردن", "خوردن بسیار سریع", "Eating very rapidly",
     ["سریع می‌خورم", "سریع میخورم", "eat rapidly", "eating fast"]),
    ("eating_alone_shame", "خوردن", "پنهان‌کاری یا خجالت هنگام خوردن", "Eating alone out of embarrassment",
     ["تنها می‌خورم", "تنها میخورم", "eat alone", "hide eating"]),
    ("distress_after_binge", "خوردن", "پشیمانی یا نفرت از خود پس از پرخوری", "Distress / disgust after binge",
     ["پشیمان", "disgust", "ashamed after"]),
    # --- alcohol -----------------------------------------------------------------
    ("craving_alcohol", "الکل", "اشتیاق شدید به نوشیدن الکل", "Strong craving for alcohol",
     ["هوس الکل", "craving alcohol", "craving"]),
    ("drinking_more", "الکل", "نوشیدن بیش از قصد قبلی", "Drinking more than intended",
     ["بیشتر از قصدم", "drink more than intended", "drinking more than"]),
    ("failed_cut_down", "الکل", "تلاش ناموفق برای کم کردن مصرف", "Unsuccessful attempts to cut down",
     ["کم کنم", "cut down", "quit drinking"]),
    ("withdrawal", "الکل", "علائم ترک", "Withdrawal symptoms",
     ["علائم ترک", "withdrawal"]),
    ("tolerance", "الکل", "تحمل (نیاز به مقدار بیشتر)", "Tolerance",
     ["تحمل", "tolerance"]),
    ("role_failure", "الکل", "اختلال در کار/خانواده به‌خاطر نوشیدن", "Role failure due to drinking",
     ["کار و خانواده", "role failure", "work problems drinking"]),
    ("continued_despite", "الکل", "ادامه مصرف با وجود آسیب", "Continued use despite harm",
     ["با وجود مشکل", "despite problems", "despite the harm"]),
]

SYMPTOM_IDS = [s[0] for s in SYMPTOMS]
S_INDEX = {sid: i for i, sid in enumerate(SYMPTOM_IDS)}

DURATION_BUCKETS = [
    ("lt2w", "کمتر از ۲ هفته", "< 2 weeks"),
    ("2w_6m", "۲ هفته تا ۶ ماه", "2 weeks – 6 months"),
    ("gt6m", "بیش از ۶ ماه", "> 6 months"),
]

CORE, COMMON, OCC = 0.85, 0.5, 0.2

# id -> dict(fa, en, probs{symptom: p}, duration prior over DURATION_BUCKETS, note)
DISORDERS = {
    "mdd": dict(
        fa="اختلال افسردگی اساسی", en="Major depressive disorder",
        probs={**{s: CORE for s in ["depressed_mood", "anhedonia"]},
               **{s: COMMON for s in ["insomnia", "fatigue", "worthlessness_guilt", "poor_concentration",
                                      "appetite_decrease", "hopelessness", "indecisiveness"]},
               **{s: OCC for s in ["hypersomnia", "psychomotor_agitation", "psychomotor_slowing",
                                   "suicidal_thoughts", "appetite_increase", "irritability", "excessive_worry"]}},
        duration=[0.05, 0.70, 0.25],
        note="دوره حداقل چند هفته‌ای با افت خلق/لذت و چند نشانه همراه."),
    "pdd": dict(
        fa="اختلال افسردگی مداوم", en="Persistent depressive disorder",
        probs={"depressed_mood": 0.8,
               **{s: COMMON for s in ["fatigue", "hopelessness", "poor_concentration", "worthlessness_guilt",
                                      "indecisiveness", "insomnia"]},
               **{s: 0.35 for s in ["appetite_decrease", "appetite_increase", "anhedonia"]},
               **{s: OCC for s in ["irritability", "hypersomnia"]},
               "suicidal_thoughts": 0.1},
        duration=[0.0, 0.05, 0.95],
        note="خلق افسرده‌ی طولانی‌مدت (معمولاً سال‌ها) با شدت کمتر و پایدارتر."),
    "gad": dict(
        fa="اختلال اضطراب فراگیر", en="Generalized anxiety disorder",
        probs={**{s: CORE for s in ["excessive_worry", "worry_hard_to_control"]},
               **{s: COMMON for s in ["restlessness", "fatigue", "poor_concentration", "irritability",
                                      "muscle_tension", "insomnia"]},
               **{s: OCC for s in ["palpitations", "dizziness"]},
               "panic_attacks": 0.12},
        duration=[0.05, 0.15, 0.80],
        note="نگرانی مفرط و دشوار برای کنترل، معمولاً حداقل حدود ۶ ماه."),
    "panic": dict(
        fa="اختلال پانیک", en="Panic disorder",
        probs={**{s: CORE for s in ["panic_attacks", "fear_of_attacks", "palpitations"]},
               **{s: COMMON for s in ["shortness_breath", "dizziness"]},
               **{s: OCC for s in ["excessive_worry", "insomnia", "avoidance_social", "fatigue"]}},
        duration=[0.10, 0.70, 0.20],
        note="حملات غیرمنتظره‌ی وحشت و نگرانی/تغییر رفتار پس از آن."),
    "sad": dict(
        fa="اختلال اضطراب اجتماعی", en="Social anxiety disorder",
        probs={**{s: CORE for s in ["fear_of_scrutiny", "avoidance_social"]},
               "social_physical": 0.55, "excessive_worry": 0.35, "palpitations": 0.25,
               **{s: OCC for s in ["depressed_mood", "poor_concentration", "dizziness"]}},
        duration=[0.02, 0.18, 0.80],
        note="ترس شدید از موقعیت‌های اجتماعی و قضاوت دیگران، معمولاً ≥ ۶ ماه."),
    "ptsd": dict(
        fa="اختلال استرس پس از سانحه", en="Post-traumatic stress disorder",
        probs={**{s: CORE for s in ["traumatic_event", "intrusive_memories"]},
               **{s: COMMON for s in ["nightmares", "avoidance_trauma", "hypervigilance", "startle",
                                      "emotional_numbness", "negative_beliefs", "insomnia", "irritability"]},
               "flashbacks": 0.45,
               **{s: OCC for s in ["depressed_mood", "anhedonia", "poor_concentration", "worthlessness_guilt"]}},
        duration=[0.03, 0.60, 0.37],
        note="پس از مواجهه با رویداد تروماتیک؛ علائم مزاحم، اجتناب، تغییر خلق و برانگیختگی."),
    "ocd": dict(
        fa="اختلال وسواسی-جبری", en="Obsessive-compulsive disorder",
        probs={"obsessions": 0.9, "ritual_time": 0.7, "compulsion_cleaning": 0.45, "compulsion_checking": 0.45,
               "excessive_worry": 0.3, **{s: OCC for s in ["insomnia", "depressed_mood", "fatigue"]}},
        duration=[0.02, 0.28, 0.70],
        note="وسواس و/یا اجبار زمان‌بر که آشکارا زندگی را مختل می‌کند."),
    "adhd": dict(
        fa="اختلال نقص توجه/بیش‌فعالی", en="ADHD",
        probs={**{s: CORE for s in ["sustained_attention", "distractibility"]}, "childhood_onset": 0.8,
               **{s: COMMON for s in ["inattention_details", "losing_things", "disorganization", "fidgeting",
                                      "impulsivity"]},
               "poor_concentration": 0.6, "interrupting": 0.35, "restlessness": 0.3,
               **{s: OCC for s in ["irritability", "insomnia"]}},
        duration=[0.0, 0.05, 0.95],
        note="الگوی پایدار بی‌توجهی و/یا بیش‌فعالی-تکانشگری با شروع در کودکی."),
    "bipolar": dict(
        fa="اختلال دوقطبی (طیف مانیا/هیپومانیا)", en="Bipolar disorder (manic/hypomanic spectrum)",
        probs={"elevated_mood": 0.7, **{s: CORE for s in ["increased_goal_activity", "reduced_sleep_need"]},
               **{s: COMMON for s in ["grandiosity", "talkativeness", "racing_thoughts", "distractibility",
                                      "risky_behavior", "irritability"]},
               "depressed_mood": 0.35, "anhedonia": 0.25,
               **{s: OCC for s in ["insomnia"]}, "suicidal_thoughts": 0.1},
        duration=[0.35, 0.50, 0.15],
        note="دوره‌های مشخص خلق بالا/تحریک‌پذیر با افزایش انرژی و نیاز کم به خواب."),
    "insomnia": dict(
        fa="اختلال بی‌خوابی", en="Insomnia disorder",
        probs={"insomnia": 0.95, "fatigue": 0.6, "poor_concentration": 0.45, "irritability": 0.4,
               **{s: OCC for s in ["depressed_mood", "excessive_worry"]}},
        duration=[0.05, 0.50, 0.45],
        note="مشکل در شروع/تداوم خواب با پیامد روزانه، حداقل چند ماه."),
    "binge": dict(
        fa="اختلال پرخوری", en="Binge-eating disorder",
        probs={"binge_episodes": 0.95, "loss_of_control_eating": 0.9, "distress_after_binge": 0.8,
               **{s: 0.6 for s in ["eating_rapidly", "eating_alone_shame"]},
               "worthlessness_guilt": 0.45, "depressed_mood": 0.3, "appetite_increase": 0.3},
        duration=[0.03, 0.50, 0.47],
        note="دوره‌های پرخوری همراه با از دست رفتن کنترل و پریشانی."),
    "aud": dict(
        fa="اختلال مصرف الکل", en="Alcohol use disorder",
        probs={**{s: CORE for s in ["craving_alcohol", "drinking_more"]},
               **{s: COMMON for s in ["failed_cut_down", "tolerance", "role_failure", "continued_despite"]},
               "withdrawal": 0.4, **{s: OCC for s in ["insomnia", "irritability", "depressed_mood"]}},
        duration=[0.02, 0.28, 0.70],
        note="الگوی مشکل‌ساز مصرف الکل با چند نشانه در یک بازه ۱۲‌ماهه."),
}

DISORDER_IDS = list(DISORDERS.keys())
D_INDEX = {d: i for i, d in enumerate(DISORDER_IDS)}

# Background (general-population) rate of each symptom in people with no disorder.
BASE_RATE_DEFAULT = 0.03
BASE_RATE = {
    "fatigue": 0.12, "insomnia": 0.10, "poor_concentration": 0.10, "irritability": 0.10,
    "excessive_worry": 0.10, "depressed_mood": 0.07, "indecisiveness": 0.06, "restlessness": 0.06,
    "distractibility": 0.07, "anhedonia": 0.04, "traumatic_event": 0.08,
}

# Comorbidity affinity (symmetric multipliers >1 make co-occurrence more likely).
AFFINITY = {
    ("mdd", "gad"): 2.5, ("mdd", "pdd"): 2.0, ("mdd", "sad"): 2.0, ("mdd", "ptsd"): 2.5,
    ("gad", "panic"): 2.5, ("gad", "sad"): 2.0, ("ocd", "mdd"): 1.5, ("adhd", "mdd"): 1.5,
    ("adhd", "aud"): 2.0, ("bipolar", "aud"): 2.0, ("mdd", "insomnia"): 2.5, ("gad", "insomnia"): 2.0,
    ("ptsd", "insomnia"): 2.0, ("ptsd", "aud"): 2.0, ("binge", "mdd"): 2.0, ("sad", "aud"): 2.0,
    ("panic", "mdd"): 1.5, ("pdd", "gad"): 1.5,
}


def affinity(a, b):
    return AFFINITY.get((a, b), AFFINITY.get((b, a), 1.0))
