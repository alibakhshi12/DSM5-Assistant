"""Inference from the exported model.json: ensemble probabilities, uncertainty, occlusion-based explanations."""
import json
import os

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(ROOT, "artifacts", "model.json")


def _sig(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


class Predictor:
    def __init__(self, path=MODEL_PATH):
        with open(path, encoding="utf-8") as f:
            self.meta = json.load(f)
        self.symptoms = self.meta["symptoms"]
        self.disorders = self.meta["disorders"]
        self.durations = self.meta["durations"]
        self.s_idx = {s["id"]: i for i, s in enumerate(self.symptoms)}
        self.dur_idx = {d["id"]: i for i, d in enumerate(self.durations)}
        self.members = [
            ([np.array(w) for w in m["W"]], [np.array(b) for b in m["b"]], m["T"]) for m in self.meta["members"]
        ]
        self.S = len(self.symptoms)

    def encode(self, symptom_ids, duration_id="2w_6m", impaired=True):
        x = np.zeros(self.S + 4)
        for s in symptom_ids:
            if s in self.s_idx:
                x[self.s_idx[s]] = 1
        x[self.S + self.dur_idx.get(duration_id, 1)] = 1
        x[self.S + 3] = 1.0 if impaired else 0.0
        return x

    def _member_probs(self, X):
        out = []
        for W, b, T in self.members:
            h = X
            for Wi, bi in zip(W[:-1], b[:-1]):
                h = np.maximum(h @ Wi + bi, 0)
            out.append(_sig((h @ W[-1] + b[-1]) / T))
        return np.stack(out)  # (members, n, D)

    def predict(self, symptom_ids, duration_id="2w_6m", impaired=True, top_k_explain=3):
        x = self.encode(symptom_ids, duration_id, impaired)
        P = self._member_probs(x[None, :])[:, 0, :]
        mean, std = P.mean(0), P.std(0)
        chosen = [s for s in symptom_ids if s in self.s_idx]
        # occlusion: drop each reported symptom and measure the change in probability
        occ = {}
        if chosen:
            Xo = np.tile(x, (len(chosen), 1))
            for r, s in enumerate(chosen):
                Xo[r, self.s_idx[s]] = 0
            Po = self._member_probs(Xo).mean(0)  # (len(chosen), D)
            occ = {s: (mean - Po[r]) for r, s in enumerate(chosen)}
        results = []
        for j, d in enumerate(self.disorders):
            contrib = sorted(((s, float(occ[s][j])) for s in occ), key=lambda t: -t[1]) if occ else []
            results.append({
                "id": d["id"], "fa": d["fa"], "en": d["en"], "note": d["note"],
                "probability": float(mean[j]), "spread": float(std[j]),
                "supporting": [{"id": s, "fa": self.symptoms[self.s_idx[s]]["fa"], "delta": round(v, 4)}
                               for s, v in contrib[:top_k_explain] if v > 0.01],
            })
        results.sort(key=lambda r: -r["probability"])
        return {
            "results": results,
            "no_pattern_probability": float(np.prod(1 - mean)),
            "safety_flag": "suicidal_thoughts" in chosen,
        }
