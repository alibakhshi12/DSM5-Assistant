"""A small multi-label deep MLP implemented in pure NumPy (manual backprop + Adam).

Architecture: input -> [Linear -> ReLU -> Dropout] x L -> Linear -> sigmoid (one output per disorder)
Loss: binary cross-entropy (multi-label, so comorbidity is representable).
"""
import numpy as np


def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


class MLP:
    def __init__(self, sizes, seed=0, dropout=0.2, l2=1e-4):
        rng = np.random.default_rng(seed)
        self.sizes, self.dropout, self.l2 = list(sizes), dropout, l2
        self.W = [rng.normal(0, np.sqrt(2.0 / sizes[i]), (sizes[i], sizes[i + 1])) for i in range(len(sizes) - 1)]
        self.b = [np.zeros(sizes[i + 1]) for i in range(len(sizes) - 1)]
        self._m = [np.zeros_like(p) for p in self.W + self.b]
        self._v = [np.zeros_like(p) for p in self.W + self.b]
        self._t = 0

    # ---- inference ---------------------------------------------------------------
    def logits(self, X):
        h = X
        for W, b in zip(self.W[:-1], self.b[:-1]):
            h = np.maximum(h @ W + b, 0)
        return h @ self.W[-1] + self.b[-1]

    # ---- training ----------------------------------------------------------------
    def _forward_train(self, X, rng):
        acts, masks, h = [X], [], X
        for W, b in zip(self.W[:-1], self.b[:-1]):
            h = np.maximum(h @ W + b, 0)
            m = (rng.random(h.shape) > self.dropout) / (1 - self.dropout)
            h = h * m
            masks.append(m)
            acts.append(h)
        return h @ self.W[-1] + self.b[-1], acts, masks

    def step(self, X, Y, rng, lr=1e-3, b1=0.9, b2=0.999, eps=1e-8):
        n = len(X)
        z, acts, masks = self._forward_train(X, rng)
        p = sigmoid(z)
        loss = -np.mean(np.sum(Y * np.log(p + 1e-9) + (1 - Y) * np.log(1 - p + 1e-9), axis=1))
        g = (p - Y) / n
        gW, gb = [None] * len(self.W), [None] * len(self.b)
        L = len(self.W)
        for i in range(L - 1, -1, -1):
            gW[i] = acts[i].T @ g + self.l2 * self.W[i]
            gb[i] = g.sum(0)
            if i > 0:
                g = (g @ self.W[i].T) * masks[i - 1] * (acts[i] > 0)
        self._t += 1
        params, grads = self.W + self.b, gW + gb
        for k, (p_, g_) in enumerate(zip(params, grads)):
            self._m[k] = b1 * self._m[k] + (1 - b1) * g_
            self._v[k] = b2 * self._v[k] + (1 - b2) * g_ * g_
            mh = self._m[k] / (1 - b1 ** self._t)
            vh = self._v[k] / (1 - b2 ** self._t)
            p_ -= lr * mh / (np.sqrt(vh) + eps)
        return loss

    def get_state(self):
        return [w.copy() for w in self.W], [b.copy() for b in self.b]

    def set_state(self, state):
        self.W, self.b = [w.copy() for w in state[0]], [b.copy() for b in state[1]]
