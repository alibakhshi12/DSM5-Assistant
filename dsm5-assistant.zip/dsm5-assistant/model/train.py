"""Train a 5-member MLP ensemble, calibrate with temperature scaling, evaluate, export weights + figures."""
import json
import os
import sys
import time

import numpy as np
from scipy.optimize import minimize_scalar
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, f1_score, roc_auc_score
from sklearn.multiclass import OneVsRestClassifier

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "data"))
sys.path.insert(0, os.path.join(ROOT, "model"))
from knowledge import DISORDER_IDS, DISORDERS, DURATION_BUCKETS, SYMPTOMS  # noqa: E402
from mlp import MLP, sigmoid  # noqa: E402

DATA = os.path.join(ROOT, "data", "synthetic")
ART = os.path.join(ROOT, "artifacts")
FIG = os.path.join(ART, "figures")
os.makedirs(FIG, exist_ok=True)

HIDDEN = (96, 48)
N_MEMBERS = 5
EPOCHS, BATCH, LR = 80, 128, 2e-3
PATIENCE = 10


def load(name):
    d = np.load(os.path.join(DATA, f"{name}.npz"))
    return d["X"].astype(np.float64), d["Y"].astype(np.float64)


def bce(p, Y):
    return float(-np.mean(Y * np.log(p + 1e-9) + (1 - Y) * np.log(1 - p + 1e-9)))


def ece(p, Y, bins=10):
    p, Y = p.ravel(), Y.ravel()
    edges = np.linspace(0, 1, bins + 1)
    idx = np.clip(np.digitize(p, edges) - 1, 0, bins - 1)
    out = 0.0
    for b in range(bins):
        m = idx == b
        if m.any():
            out += m.mean() * abs(Y[m].mean() - p[m].mean())
    return float(out)


def fit_temperature(z, Y):
    res = minimize_scalar(lambda T: bce(sigmoid(z / T), Y), bounds=(0.2, 5.0), method="bounded")
    return float(res.x)


def metrics(P, Y):
    pred = (P >= 0.5).astype(int)
    top1 = np.mean([Y[i, np.argmax(P[i])] == 1 for i in range(len(P)) if Y[i].sum() > 0])
    top3 = np.mean([Y[i, np.argsort(-P[i])[:3]].sum() > 0 for i in range(len(P)) if Y[i].sum() > 0])
    return dict(
        macro_auroc=float(np.mean([roc_auc_score(Y[:, j], P[:, j]) for j in range(Y.shape[1])])),
        macro_auprc=float(np.mean([average_precision_score(Y[:, j], P[:, j]) for j in range(Y.shape[1])])),
        macro_f1=float(f1_score(Y, pred, average="macro", zero_division=0)),
        micro_f1=float(f1_score(Y, pred, average="micro", zero_division=0)),
        top1_hit=float(top1), top3_hit=float(top3), bce=bce(np.clip(P, 1e-6, 1 - 1e-6), Y), ece=ece(P, Y),
    )


def train_member(seed, Xtr, Ytr, Xva, Yva):
    net = MLP([Xtr.shape[1], *HIDDEN, Ytr.shape[1]], seed=seed, dropout=0.2, l2=1e-4)
    rng = np.random.default_rng(1000 + seed)
    best, best_state, bad, hist = 1e9, None, 0, []
    for ep in range(EPOCHS):
        order = rng.permutation(len(Xtr))
        tr_loss = []
        for s in range(0, len(order), BATCH):
            idx = order[s:s + BATCH]
            tr_loss.append(net.step(Xtr[idx], Ytr[idx], rng, lr=LR))
        va = bce(sigmoid(net.logits(Xva)), Yva)
        hist.append((float(np.mean(tr_loss)) / Ytr.shape[1], va))
        if va < best - 1e-5:
            best, best_state, bad = va, net.get_state(), 0
        else:
            bad += 1
            if bad >= PATIENCE:
                break
    net.set_state(best_state)
    return net, hist


def ensemble_probs(members, temps, X):
    return np.mean([sigmoid(m.logits(X) / T) for m, T in zip(members, temps)], axis=0)


def main():
    t0 = time.time()
    Xtr, Ytr = load("train")
    Xva, Yva = load("val")
    Xte, Yte = load("test")
    members, temps, hists = [], [], []
    for k in range(N_MEMBERS):
        net, h = train_member(k, Xtr, Ytr, Xva, Yva)
        T = fit_temperature(net.logits(Xva), Yva)
        members.append(net)
        temps.append(T)
        hists.append(h)
        print(f"member {k}: epochs={len(h)} val_bce={min(x[1] for x in h):.4f} T={T:.3f}", flush=True)

    P_raw = np.mean([sigmoid(m.logits(Xte)) for m in members], axis=0)
    P_cal = ensemble_probs(members, temps, Xte)
    single = sigmoid(members[0].logits(Xte) / temps[0])

    # Baseline: one-vs-rest logistic regression
    lr = OneVsRestClassifier(LogisticRegression(C=1.0, max_iter=2000)).fit(Xtr, Ytr)
    P_lr = lr.predict_proba(Xte)

    res = {
        "mlp_ensemble_calibrated": metrics(P_cal, Yte),
        "mlp_ensemble_uncalibrated": metrics(P_raw, Yte),
        "mlp_single_calibrated": metrics(single, Yte),
        "logistic_regression": metrics(P_lr, Yte),
    }

    # Paired bootstrap over test cases (macro AUROC, MLP ensemble vs logistic regression)
    rngb, a_m, a_l = np.random.default_rng(11), [], []
    for _ in range(300):
        idx = rngb.integers(0, len(Yte), len(Yte))
        a_m.append(np.mean([roc_auc_score(Yte[idx, j], P_cal[idx, j]) for j in range(Yte.shape[1])]))
        a_l.append(np.mean([roc_auc_score(Yte[idx, j], P_lr[idx, j]) for j in range(Yte.shape[1])]))
    a_m, a_l = np.array(a_m), np.array(a_l)
    res["bootstrap"] = {
        "n_resamples": 300,
        "mlp_auroc_ci95": [float(np.percentile(a_m, 2.5)), float(np.percentile(a_m, 97.5))],
        "lr_auroc_ci95": [float(np.percentile(a_l, 2.5)), float(np.percentile(a_l, 97.5))],
        "diff_mean": float(np.mean(a_m - a_l)),
        "diff_ci95": [float(np.percentile(a_m - a_l, 2.5)), float(np.percentile(a_m - a_l, 97.5))],
    }

    # Robustness: drop reported symptoms with increasing probability
    rng = np.random.default_rng(7)
    S = len(SYMPTOMS)
    drops = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5]
    rob = {"drop": drops, "mlp": [], "lr": []}
    for d in drops:
        Xd = Xte.copy()
        mask = (rng.random((len(Xd), S)) < d)
        Xd[:, :S] = Xd[:, :S] * (~mask)
        rob["mlp"].append(float(np.mean([roc_auc_score(Yte[:, j], ensemble_probs(members, temps, Xd)[:, j])
                                         for j in range(Yte.shape[1])])))
        rob["lr"].append(float(np.mean([roc_auc_score(Yte[:, j], lr.predict_proba(Xd)[:, j])
                                        for j in range(Yte.shape[1])])))
    res["robustness"] = rob
    res["per_class_auroc"] = {
        d: {"mlp": float(roc_auc_score(Yte[:, j], P_cal[:, j])), "lr": float(roc_auc_score(Yte[:, j], P_lr[:, j]))}
        for j, d in enumerate(DISORDER_IDS)
    }
    res["temperatures"] = temps
    res["config"] = dict(hidden=list(HIDDEN), members=N_MEMBERS, epochs_max=EPOCHS, batch=BATCH, lr=LR,
                         dropout=0.2, l2=1e-4, train=len(Xtr), val=len(Xva), test=len(Xte),
                         epochs_run=[len(h) for h in hists])
    res["train_seconds"] = round(time.time() - t0, 1)

    # ---- export ------------------------------------------------------------------
    def r(a):
        return np.round(a, 4).tolist()

    export = {
        "disorders": [{"id": d, "fa": DISORDERS[d]["fa"], "en": DISORDERS[d]["en"], "note": DISORDERS[d]["note"]}
                      for d in DISORDER_IDS],
        "symptoms": [{"id": s[0], "group": s[1], "fa": s[2], "en": s[3]} for s in SYMPTOMS],
        "durations": [{"id": d[0], "fa": d[1], "en": d[2]} for d in DURATION_BUCKETS],
        "members": [{"W": [r(w) for w in m.W], "b": [r(b) for b in m.b], "T": round(T, 4)}
                    for m, T in zip(members, temps)],
    }
    with open(os.path.join(ART, "model.json"), "w", encoding="utf-8") as f:
        json.dump(export, f, ensure_ascii=False, separators=(",", ":"))
    with open(os.path.join(ART, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, indent=2)

    # ---- figures -----------------------------------------------------------------
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})

    fig, ax = plt.subplots(figsize=(5.2, 3.4))
    for k, h in enumerate(hists):
        ax.plot([x[0] for x in h], color="#9db4d8", lw=1, label="train (dropout on)" if k == 0 else None)
        ax.plot([x[1] for x in h], color="#1f4e9c", lw=1.2, label="validation" if k == 0 else None)
    ax.set_xlabel("epoch")
    ax.set_ylabel("BCE per label")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "training_curves.png"), dpi=200)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(4.2, 4.0))
    for P, lab, c in [(P_raw, f"uncalibrated (ECE={res['mlp_ensemble_uncalibrated']['ece']:.3f})", "#d9822b"),
                      (P_cal, f"temperature-scaled (ECE={res['mlp_ensemble_calibrated']['ece']:.3f})", "#1f4e9c")]:
        edges = np.linspace(0, 1, 11)
        idx = np.clip(np.digitize(P.ravel(), edges) - 1, 0, 9)
        xs, ys = [], []
        for b in range(10):
            m = idx == b
            if m.sum() > 20:
                xs.append(P.ravel()[m].mean())
                ys.append(Yte.ravel()[m].mean())
        ax.plot(xs, ys, marker="o", ms=4, color=c, label=lab)
    ax.plot([0, 1], [0, 1], "--", color="#888", lw=1)
    ax.set_xlabel("predicted probability")
    ax.set_ylabel("observed frequency")
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "reliability.png"), dpi=200)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.4, 3.4))
    x = np.arange(len(DISORDER_IDS))
    ax.bar(x - 0.2, [res["per_class_auroc"][d]["lr"] for d in DISORDER_IDS], 0.4, color="#b9c3d6", label="Logistic regression")
    ax.bar(x + 0.2, [res["per_class_auroc"][d]["mlp"] for d in DISORDER_IDS], 0.4, color="#1f4e9c", label="MLP ensemble")
    ax.set_xticks(x, DISORDER_IDS, rotation=45, ha="right")
    lo = min(min(v["lr"], v["mlp"]) for v in res["per_class_auroc"].values())
    ax.set_ylim(max(0.5, lo - 0.03), 1.0)
    ax.set_ylabel("AUROC")
    ax.legend(frameon=False, loc="lower right")
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "per_class_auroc.png"), dpi=200)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(5.2, 3.4))
    ax.plot(drops, rob["mlp"], marker="o", color="#1f4e9c", label="MLP ensemble")
    ax.plot(drops, rob["lr"], marker="s", color="#b0b8c8", label="Logistic regression")
    ax.set_xlabel("probability of dropping each reported symptom")
    ax.set_ylabel("macro AUROC")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "robustness.png"), dpi=200)
    plt.close(fig)

    print(json.dumps({k: res[k] for k in ["mlp_ensemble_calibrated", "mlp_ensemble_uncalibrated",
                                           "logistic_regression"]}, indent=1))
    print("robustness:", rob)
    print("seconds:", res["train_seconds"])


if __name__ == "__main__":
    main()
