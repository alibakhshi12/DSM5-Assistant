// Verifies the in-browser inference gives the same probabilities as the Python predictor.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'ui', 'index.html'), 'utf8');
const start = html.indexOf('/* ---------------- in-browser inference');
const end = html.indexOf('/* ---------------------------------- rendering');
const M = JSON.parse(fs.readFileSync(path.join(root, 'artifacts', 'model.json'), 'utf8'));
const state = {sel: new Set(process.argv[2].split(',').filter(Boolean)), duration: process.argv[3], impaired: process.argv[4] === '1'};
eval(html.slice(start, end) + `;globalThis.out = localPredict();`);
console.log(JSON.stringify(out.results.slice(0, 3).map(r => [r.id, +r.probability.toFixed(4), r.supporting.map(s => s.id)])));
