"""Sanity tests: hand-written vignettes, API contract, safety flag, extractor fallback. Run: python -I tests/test_pipeline.py"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for sub in ("data", "model", "backend"):
    sys.path.insert(0, os.path.join(ROOT, sub))

import app  # noqa: E402
import llm  # noqa: E402
from infer import Predictor  # noqa: E402
from knowledge import SYMPTOMS  # noqa: E402

P = Predictor()
VIGNETTES = {  # hand-written, independent of the generator's random draws
    "mdd": (["depressed_mood", "anhedonia", "insomnia", "fatigue", "hopelessness"], "2w_6m", True),
    "gad": (["excessive_worry", "worry_hard_to_control", "restlessness", "muscle_tension"], "gt6m", True),
    "panic": (["panic_attacks", "fear_of_attacks", "palpitations", "shortness_breath"], "2w_6m", True),
    "sad": (["fear_of_scrutiny", "avoidance_social", "social_physical"], "gt6m", True),
    "ptsd": (["traumatic_event", "intrusive_memories", "nightmares", "hypervigilance"], "2w_6m", True),
    "ocd": (["obsessions", "compulsion_checking", "ritual_time"], "gt6m", True),
    "adhd": (["sustained_attention", "distractibility", "disorganization", "childhood_onset"], "gt6m", True),
    "bipolar": (["elevated_mood", "increased_goal_activity", "reduced_sleep_need", "talkativeness"], "lt2w", True),
    "insomnia": (["insomnia", "fatigue", "poor_concentration"], "2w_6m", True),
    "binge": (["binge_episodes", "loss_of_control_eating", "distress_after_binge"], "2w_6m", True),
    "aud": (["craving_alcohol", "drinking_more", "failed_cut_down", "tolerance"], "gt6m", True),
}


def test_vignettes():
    for expected, (sym, dur, imp) in VIGNETTES.items():
        top = P.predict(sym, dur, imp)["results"][0]["id"]
        assert top == expected, f"{expected}: got {top}"


def test_no_symptoms_means_no_pattern():
    r = P.predict([], "lt2w", False)
    assert r["no_pattern_probability"] > 0.8 and r["results"][0]["probability"] < 0.1


def test_probabilities_valid():
    r = P.predict(VIGNETTES["mdd"][0])
    assert all(0 <= x["probability"] <= 1 for x in r["results"])
    assert len(r["results"]) == 12


def test_safety_flag_and_api():
    c = app.app.test_client()
    j = c.post("/api/predict", json={"symptoms": ["depressed_mood", "suicidal_thoughts"]}).json
    assert j["safety_flag"] is True and "disclaimer" in j
    assert c.post("/api/predict", json={"symptoms": ["not_a_symptom"]}).status_code == 200
    assert c.post("/api/extract", json={"text": ""}).status_code == 400


def test_keyword_extractor():
    kw = {s[0]: s[4] for s in SYMPTOMS}
    out = llm.extract_with_keywords("I can't sleep and feel exhausted for years", kw)
    assert {"insomnia", "fatigue"} <= set(out["symptoms"]) and out["duration"] == "gt6m"


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok", name)
