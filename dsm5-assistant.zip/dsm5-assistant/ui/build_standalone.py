"""Inline artifacts/model.json into ui/index.html -> dist/dsm5-assistant-standalone.html (works offline, no server)."""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
html = open(os.path.join(ROOT, "ui", "index.html"), encoding="utf-8").read()
model = open(os.path.join(ROOT, "artifacts", "model.json"), encoding="utf-8").read()
marker = '<script id="model-inline" type="application/json"></script>'
assert marker in html
out = html.replace(marker, f'<script id="model-inline" type="application/json">{model}</script>')
os.makedirs(os.path.join(ROOT, "dist"), exist_ok=True)
path = os.path.join(ROOT, "dist", "dsm5-assistant-standalone.html")
open(path, "w", encoding="utf-8").write(out)
print(path, round(len(out) / 1024), "KB")
